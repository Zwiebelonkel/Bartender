export const GlobalSettings = {
    minSpawnDelay: 5000,
    maxSpawnDelay: 10000,
    difficulty: 0,
    money: 0
};